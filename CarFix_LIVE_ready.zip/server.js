import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

const app=express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

function cleanPlate(s){return String(s||"").toUpperCase().replace(/[\s-]/g,"");}

app.get("/api/vehicle", async (req,res)=>{
  try{
    const country=(req.query.country||"FR").toUpperCase();
    const plate=cleanPlate(req.query.plate);
    if(!plate) return res.status(400).json({error:"Mungon targa."});

    if(country==="FR"){
      if(!process.env.FR_RAPIDAPI_KEY)
        return res.status(503).json({error:"FR_RAPIDAPI_KEY nuk është vendosur në server."});
      const url=`https://${process.env.FR_RAPIDAPI_HOST}/fr?plaque=${encodeURIComponent(plate)}`;
      const r=await fetch(url,{headers:{
        "Content-Type":"application/json",
        "x-rapidapi-host":process.env.FR_RAPIDAPI_HOST,
        "x-rapidapi-key":process.env.FR_RAPIDAPI_KEY
      }});
      const raw=await r.json();
      if(!r.ok || raw.error) return res.status(404).json({error:raw.message||"Makina nuk u gjet."});
      const d=raw.data||{};
      return res.json({source:"FR API Plaque",vehicle:{
        plate:d.AWN_immat||plate, make:d.AWN_marque, model:d.AWN_modele,
        version:d.AWN_version, year:d.AWN_date_mise_en_circulation,
        engine:d.AWN_code_moteur, cc:d.AWN_cylindre_capacite,
        fuel:d.AWN_energie_description||d.AWN_energie,
        hp:d.AWN_puissance_chevaux, kw:d.AWN_puissance_KW,
        gearbox:d.AWN_boite_vitesse||d.AWN_boite_de_vitesses,
        vin:d.AWN_VIN, ktype:d.AWN_k_type, body:d.AWN_style_carrosserie
      }});
    }

    if(country==="AL"){
      if(!process.env.AL_USERNAME)
        return res.status(503).json({error:"AL_USERNAME nuk është vendosur në server."});
      // RegCheck SOAP/GET endpoint. The API documents Albania as CheckAlbania.
      const url=`${process.env.AL_ENDPOINT}/CheckAlbania?RegistrationNumber=${encodeURIComponent(plate)}&username=${encodeURIComponent(process.env.AL_USERNAME)}`;
      const r=await fetch(url);
      const xml=await r.text();
      if(!r.ok) return res.status(404).json({error:"Kërkimi shqiptar dështoi."});
      const vehicleJson=(xml.match(/<vehicleJson[^>]*>([\s\S]*?)<\/vehicleJson>/i)||[])[1];
      if(!vehicleJson) return res.status(404).json({error:"Nuk u gjetën të dhëna për këtë targë."});
      const decoded=vehicleJson.replace(/&quot;/g,'"').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
      let d; try{d=JSON.parse(decoded)}catch{d={}};
      return res.json({source:"RegCheck Albania",vehicle:{
        plate, make:d.CarMake?.CurrentTextValue||d.MakeDescription?.CurrentTextValue,
        model:d.CarModel?.CurrentTextValue||d.ModelDescription?.CurrentTextValue,
        version:d.Description, year:d.RegistrationYear,
        cc:d.EngineSize?.CurrentTextValue, fuel:d.FuelType?.CurrentTextValue,
        vin:d.VechileIdentificationNumber, hp:d.EnginePower?.CurrentTextValue
      }});
    }
    res.status(400).json({error:"Shtet i panjohur."});
  }catch(e){
    console.error(e);
    res.status(500).json({error:"Gabim serveri."});
  }
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`CarFix running on http://localhost:${port}`));