let country="FR";
document.querySelectorAll(".sel").forEach(b=>b.onclick=()=>{
 document.querySelectorAll(".sel").forEach(x=>x.classList.remove("active"));
 b.classList.add("active"); country=b.dataset.c;
 document.getElementById("plate").placeholder=country==="FR"?"Targë franceze, p.sh. AB-123-CD":"Targë shqiptare, p.sh. AB123CD";
});
document.getElementById("go").onclick=async()=>{
 const plate=document.getElementById("plate").value.trim();
 const status=document.getElementById("status"), out=document.getElementById("out");
 if(!plate){status.textContent="Shkruaj targën.";return}
 status.textContent="Duke kërkuar...";
 out.classList.add("hidden");
 try{
  const r=await fetch(`/api/vehicle?country=${country}&plate=${encodeURIComponent(plate)}`);
  const j=await r.json();
  if(!r.ok) throw new Error(j.error||"Nuk u gjet.");
  const v=j.vehicle||{};
  const row=(label,val)=>val?`<div class="spec"><small>${label}</small><b>${val}</b></div>`:"";
  out.innerHTML=`<div class="source">LIVE • ${j.source}</div>
  <h2>${v.make||"—"} ${v.model||""}</h2><p>${v.version||"Version i padisponueshëm"}</p>
  <div class="specs">${row("Viti / regjistrimi",v.year)}${row("Motor",v.engine)}${row("Fuqia",v.hp?`${v.hp} HP`:v.kw?`${v.kw} kW`:"")}${row("Kubikazhi",v.cc?`${v.cc} cc`:"")}${row("Karburanti",v.fuel)}${row("KType",v.ktype)}${row("VIN",v.vin)}</div>
  <hr><div class="service-row"><b>🛢️ Vaj</b><span>Do të lidhet me databazën e specifikimeve sipas KType/kodit të motorit.</span></div>
  <div class="service-row"><b>🔧 Filtrat</b><span>Do të lidhen me databazën e servisit për këtë variant.</span></div>`;
  out.classList.remove("hidden"); status.textContent="";
 }catch(e){status.textContent=e.message}
};