# CarFix LIVE

Ky version është gati për deploy në një server Node.js.

## 1. Instalimi
npm install

## 2. Konfigurimi
Kopjo `.env.example` në `.env` dhe vendos:
- `FR_RAPIDAPI_KEY` për API-n franceze
- `AL_USERNAME` për RegCheck/Albania

Mos i vendos këto çelësa në `public/app.js`.

## 3. Nisja
npm start

## 4. API
Frontend: `/`
Kërkimi: `/api/vehicle?country=FR&plate=AB123CD`

## Çfarë mungon për versionin final
- databaza e vajit sipas KType/kodit të motorit
- databaza e filtrave dhe vendndodhjeve
- histori makinash
- ruajtja e makinave
- login
- deploy publik HTTPS
